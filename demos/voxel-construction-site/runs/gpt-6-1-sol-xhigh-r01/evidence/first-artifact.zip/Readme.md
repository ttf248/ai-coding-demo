# 体素微缩建筑工地 · 自主设计版

## 本轮设计授权

> 允许你理解输入的需求，针对需求进行优化，按照你理解的更好的设计，进行具体的开发实现。

本轮标记为 **自主设计版 / design-enhanced**。原任务使用 v1，正文未改写。完整输入见 [prompt.md](prompt.md)，结构化授权与设计记录见 [design-scope.json](design-scope.json)。不能与未包含授权的旧实验标记为原始输入一致。

## 设计决策

以实体工作桌为载体提供基坑施工与装配吊装两套沙盘；分配独立作业区和单向车道，机械状态随时间联动。

## 执行条件

用户指定 gpt-6.1-sol，xhigh；在当前 Codex 会话直接执行，无子代理、无人工代码修改。同一会话连续完成多个主题，未保存全部系统上下文，不声明独立会话或公平性能比较。日期：2026-10-09。

## 运行与验证

用浏览器直接打开 [index.html](index.html)，或从仓库静态服务器进入。无后端、CDN 或远程素材，可离线直接打开。

## 需求解释与实现边界

正文同时要求 Three.js r160 CDN 与不引用外部资源；下载指定版本后内嵌库，保留许可，最终单 HTML 无运行时外部依赖。60FPS 为设计目标，实际性能依赖 GPU。固定机械包络、车辆间距和单向车道降低碰撞风险，不声称通用物理碰撞引擎。

## 技术来源

- [Three.js r160 source](https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js)
- [InstancedMesh 官方文档](https://threejs.org/docs/pages/InstancedMesh.html)
