# Pixel Flow · GPT 6.1 Sol xhigh

Three.js 图片采样粒子、原始位置与颜色保留、初始打散、局部吸引及完整还原；MediaPipe Hand Landmarker 张掌/握拳/捏合识别，掌心跟随力场。

## 运行

直接打开可使用手动模式。摄像头建议 localhost / HTTPS；首次联网下载 MediaPipe 模型与 WASM，需授权。上传图片仅在本机处理；关闭摄像头停止轨道。无真实摄像头测试时，不把手动模式记为手势验收通过。

## 实验条件与边界

- 模型：用户指定的 `gpt-6-1-sol`；档位：`xhigh`；日期：2026-10-23；工具：Codex。
- 按用户要求使用当前会话，未委派子代理。批量任务正文采用 v1，原文与批量指令见 [输入快照](prompt.md)。
- 2026-10-23 用户追加输入原文：`继续`。本轮继续完成同一批产物。
- 未读取其他分支、其他工作目录或远程中的历史答案。系统与开发者上下文没有完整转录，输入完整性标记为 partial；同会话连续执行不构成隔离公平评测。
- 首次产物在测试前保存在 [initial.zip](evidence/initial.zip)；测试修复见 [修复记录](evidence/repairs.md)，结果见 [验证记录](evidence/validation.md)。无人工修改。

## 参考

[MediaPipe 官方 Web 指南](https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker/web_js)。
