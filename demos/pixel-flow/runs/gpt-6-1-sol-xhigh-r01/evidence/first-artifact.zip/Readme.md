# Pixel Flow · 自主设计版

## 本轮设计授权

> 允许你理解输入的需求，针对需求进行优化，按照你理解的更好的设计，进行具体的开发实现。

本轮标记为 **自主设计版 / design-enhanced**。原任务使用 v1，正文未改写。完整输入见 [prompt.md](prompt.md)，结构化授权与设计记录见 [design-scope.json](design-scope.json)。不能与未包含授权的旧实验标记为原始输入一致。

## 设计决策

设计暗色粒子工作室；加入默认示例、图像采样、手势状态和鼠标替代交互，摄像头必须由用户主动启用。

## 执行条件

用户指定 gpt-6.1-sol，xhigh；在当前 Codex 会话直接执行，无子代理、无人工代码修改。同一会话连续完成多个主题，未保存全部系统上下文，不声明独立会话或公平性能比较。日期：2026-10-09。

## 运行与验证

用浏览器直接打开 [index.html](index.html)，或从仓库静态服务器进入。此案例包含外部 CDN/素材/模型，相关功能需要联网。

## 需求解释与实现边界

Three.js 已内嵌；仅主动开启摄像头时加载 MediaPipe 模型和 WASM。摄像头关闭、页面隐藏与卸载会停止视频流。提供鼠标/触摸替代操作。

## 技术来源

- [Three.js r160 source](https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js)
- [InstancedMesh 官方文档](https://threejs.org/docs/pages/InstancedMesh.html)
- [MediaPipe Web Hand Landmarker 官方文档](https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker/web_js)
