# Pixel Flow · GPT 6 Astra xhigh

## 原始输入与执行条件

见 [完整输入快照](prompt.md)。任务正文采用 v1。用户指定模型 gpt-6-astra、档位 xhigh；在当前会话直接执行，没有委派子代理。11 个活跃案例共享会话上下文，不能视为隔离的独立同题测评。

## 运行

联网打开 index.html。默认图片程序生成；上传照片后初始为散落粒子。启用摄像头需权限及 HTTPS/localhost；也可按住画布操作。

## 实现与复盘

Three.js r160；MediaPipe Tasks Vision 0.10.22 HandLandmarker，模型通过 Google CDN 加载。张掌局部吸引、握拳停止吸引、捏合全局还原。实际摄像头与真人手势质量需在有摄像头的设备上复验。

## 验证

首次实现已生成，验证记录在本轮结束时补充。

## API 参考

[Three.js 官方文档](https://threejs.org/docs/)；[MediaPipe Web 手部识别文档](https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker/web_js)。仅查询库文档，没有读取历史实验实现。
