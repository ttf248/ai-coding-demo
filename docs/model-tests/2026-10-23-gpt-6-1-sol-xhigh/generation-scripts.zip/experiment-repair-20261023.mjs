import fs from 'node:fs';
const run='gpt-6-1-sol-xhigh-r01';
const lib=fs.readFileSync('test-results/three-r160.min.js','utf8').replace(/<\/script/gi,'<\\/script');
for(const topic of ['neo-gothic-tower-city','voxel-construction-site','pixel-flow']){
 const dir=`demos/${topic}/runs/${run}`,file=`${dir}/index.html`;
 const html=fs.readFileSync(file,'utf8');
 fs.writeFileSync(file,html.replace(/<script>[\s\S]*?<\/script>/,()=>`<script>${lib}</script>`));
 fs.appendFileSync(`${dir}/evidence/repairs.md`,'\n- 首次浏览器运行发现内嵌 Three.js 的 `$&` 被字符串替换当成替换标记，导致脚本截断；改为回调插入，恢复上游库原文。首次错误产物保留在 initial.zip。\n');
}
