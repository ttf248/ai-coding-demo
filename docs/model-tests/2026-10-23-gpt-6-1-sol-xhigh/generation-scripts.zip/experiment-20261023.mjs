import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {hash} from './lib.mjs';

// 本轮输入、模型和环境的归档工具，不生成或修改任务正文。
const model='gpt-6-1-sol', effort='xhigh', runId=`${model}-${effort}-r01`;
const models=JSON.parse(fs.readFileSync('catalog/models.json','utf8'));
if(!models.some(m=>m.id===model)) {
  models.push({id:model,label:'GPT 6.1 Sol'});
  fs.writeFileSync('catalog/models.json',JSON.stringify(models,null,2)+'\n');
}
const topics=JSON.parse(execFileSync(process.execPath,['scripts/topic-status.mjs','list','--json'],{encoding:'utf8'}));
const request='所有的案例 demo 全部都做一遍，模型名称 gpt-6-1-sol 档位 xhigh, 用当前会话就好了，模型名称我已经告诉你。';
for(const topic of topics) {
  const versions=fs.readdirSync(`demos/${topic}/prompts`).filter(v=>/^v\d+$/.test(v)).sort((a,b)=>Number(a.slice(1))-Number(b.slice(1)));
  const version=versions.at(-1), meta=JSON.parse(fs.readFileSync(`demos/${topic}/topic.json`,'utf8'));
  const dir=`demos/${topic}/runs/${runId}`;
  if(fs.existsSync(dir)) continue;
  execFileSync(process.execPath,['scripts/new-demo.mjs','--topic',topic,'--title',`${meta.title} · GPT 6.1 Sol xhigh`,'--model',model,'--effort',effort,'--type',topic==='bluebook'?'app':['life-diary','meditation','youtube-ui'].includes(topic)?'prototype':'single-html','--prompt',version]);
  const input=`# 本轮用户指令（原文）\n\n${request}\n\n# 执行的主题任务正文（${version}，原文）\n\n${fs.readFileSync(`demos/${topic}/prompts/${version}/prompt.md`,'utf8')}\n\n# 用户提供的仓库规则（原文）\n\n${fs.readFileSync('AGENTS.md','utf8')}`;
  fs.writeFileSync(`${dir}/prompt.md`,input);
  const run=JSON.parse(fs.readFileSync(`${dir}/run.json`,'utf8'));
  Object.assign(run,{date:'2026-10-23',description:meta.description,stack:topic==='bluebook'?['React 18','TypeScript','Tailwind CSS','Zustand','react-lazyload','Vite']:['HTML','CSS','JavaScript',...(['voxel-construction-site','neo-gothic-tower-city','pixel-flow'].includes(topic)?['Three.js']:[])],tags:['当前会话','独立实现']});
  run.input={file:'prompt.md',hash:hash(input),completeness:'partial',notes:'完整保留用户批量指令、选用任务正文和用户提供的 AGENTS.md。宿主系统/开发者上下文及工具交互未作为原始输入完整转录；同一会话连续完成 11 个主题，不是隔离会话的公平评测。'};
  run.environment={tool:'Codex',notes:'Windows PowerShell；模型名称 gpt-6-1-sol、档位 xhigh 由用户明确提供；按用户要求复用当前会话，未委派子代理。未获取其他分支、远程或其他工作目录的历史实现。默认选择参与主题的最大提示词版本；stock-watching 已归档，跳过。'};
  run.changes=['2026-10-23：当前会话首次独立实现；无人工代码修改。首次产物在首次浏览器验证前保存于 evidence/initial.zip，后续修复见 evidence/repairs.md。'];
  fs.writeFileSync(`${dir}/run.json`,JSON.stringify(run,null,2)+'\n');
}
console.log(topics.map(t=>`${t}: ${runId}`).join('\n'));
