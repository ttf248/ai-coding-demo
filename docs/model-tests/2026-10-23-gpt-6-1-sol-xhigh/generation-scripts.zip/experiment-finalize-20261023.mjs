import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {loadCatalog} from './lib.mjs';
const reportDir='docs/model-tests/2026-10-23-gpt-6-1-sol-xhigh';
fs.mkdirSync(reportDir+'/screenshots',{recursive:true});
const checks=JSON.parse(fs.readFileSync('.cache/model-test-20261023/experiment-20261023.json','utf8'));
const camera=JSON.parse(fs.readFileSync('.cache/model-test-20261023/experiment-camera-20261023.json','utf8'));
const site=JSON.parse(fs.readFileSync('.cache/model-test-20261023/experiment-site-20261023.json','utf8'));
const touch=JSON.parse(fs.readFileSync('.cache/model-test-20261023/experiment-touch-20261023.json','utf8'));
assert(checks.every(c=>c.pass));assert(camera.pass&&site.pass&&touch.pass);
const runs=loadCatalog().runs.filter(r=>r.runId==='gpt-6-1-sol-xhigh-r01');
const rows=[];
const lines=['# 本轮验证结果','','执行日期：2026-10-23。Chromium headless，WebGL 使用 SwiftShader；模拟触摸不等于真实手机硬件验收。',''];
for(const r of runs){
 const dir=r.directory,m=JSON.parse(fs.readFileSync(`${dir}/run.json`,'utf8')),smoke=checks.find(c=>c.label.startsWith(r.topicId+' HTTP'));
 assert(smoke?.pass);
 m.status='ready';
 const fixes=fs.readFileSync(`${dir}/evidence/repairs.md`,'utf8').split('\n').filter(s=>s.startsWith('- '));
 m.changes.push(...fixes.map(s=>'2026-10-23 自动验证修复：'+s.slice(2)));
 m.changes=[...new Set(m.changes)];
 fs.writeFileSync(`${dir}/run.json`,JSON.stringify(m,null,2)+'\n');
 let validation=`# 验证记录\n\n2026-10-23，Chromium headless（GPU 使用 SwiftShader），Codex 当前会话；未委派子代理。\n\n- HTTP 入口与原始输入链接：通过。\n- 390px 视口：无页面横向溢出。\n- file:// 直接打开：${m.preview.kind==='static'?'通过。':'构建型 React 项目，使用提交的 previews 产物进行 HTTP 预览；不将 TSX 源码入口作为静态预览。'}\n- 浏览器未捕获 JavaScript 页面异常。外部素材可能受网络影响，网络要求已在元数据登记。\n`;
 const relevant={
  'circuit-lab':'串联 12V/100Ω/200Ω 电流 0.04A；并联支路 0.12A、0.06A、总电流 0.18A；断开开关零电流；短路和冲突源有提示。390px 触摸连线、拖动保留连接、删除清除导线均通过。',
  'pathfinding-lab':'加权预设 BFS 路径 23 步、总代价 99；Dijkstra 与 A* 均为 25 步、总代价 25；封闭终点不可达；暂停、单步及移动触摸绘制通过。',
  'fantasy-map-generator':'相同种子与参数逐格一致；不同种子不同；排水树不存在向更高填洼水面的边；放大后的画笔修改地形，触摸画笔通过；PNG 导出通过。',
  'fluid-simulation':'GPU 染料非零、随求解演化；暂停帧稳定；清空归零；96 长边重建通过，gl.getError() 为 0；PNG 下载、触摸注入与 WebGL 不支持时提示通过。',
  'bluebook':'20 条初始内容、点赞、搜索、滚动加载至少 40 条、详情、图片上传和本机发布通过。TypeScript 检查与 Vite build 通过，产物在 previews。移动下拉刷新已实现，自动化未单独断言其拉动阈值；图片失败回退已实现。',
  'life-diary':'7 个界面检查；日记保存本机并读取验证通过，输入计数与本地交互可用。AI 为本地演示回复，提醒与隐私锁为原型。',
  'meditation':'6 个界面检查；呼吸节拍推进、播放进度计时通过；音频为 Web Audio 合成环境音。不是实际指导音频课程。',
  'youtube-ui':'5 个模块检查；订阅状态切换、评论计数通过；分享、收藏、搜索、草稿交互已实现。使用演示短片，未接入 YouTube 服务。',
  'neo-gothic-tower-city':'WebGL 场景渲染；街巷模式键盘移动与建筑占地区域碰撞测试通过；390px 和直接打开通过。未做真实设备长时间性能验收。',
  'voxel-construction-site':'两个施工场景切换、设备速度 2×、暴雨开关与 WebGL 渲染通过；390px 与直接打开通过。碰撞约束主要通过区域和轨迹布置实现，未证明所有动态姿态绝无几何相交，未宣称达到硬件 60FPS。',
  'pixel-flow':'本地图片采样、打散、完整还原、重采样和触摸吸引通过。真实 MediaPipe 模型与 WASM 成功加载；模拟视频设备启动、权限拒绝提示及关闭释放轨道通过。未用真人手部验证张掌、握拳、捏合识别成功率。'
 }[r.topicId];
 validation+='\n## 主题验收\n\n'+relevant+'\n\n## 验证脚本\n\n根目录执行 `node tests/experiment-gpt-6-1-sol-20261023.mjs`（需先运行端口 43903 的静态服务器）；站点、摄像头、触摸专项分别见 tests/experiment-site-20261023.mjs、tests/experiment-camera-20261023.mjs、tests/experiment-touch-20261023.mjs。\n';
 fs.writeFileSync(`${dir}/evidence/validation.md`,validation);
 if(!fixes.length)fs.appendFileSync(`${dir}/evidence/repairs.md`,'\n本轮验证未对该主题的首次源码追加修复。\n');
 const zip=fs.readFileSync(`${dir}/evidence/initial.zip`),digest=crypto.createHash('sha256').update(zip).digest('hex');
 lines.push(`## ${m.title}`,'',relevant,'',`首次快照 SHA-256：\`${digest}\`。`,'');
 const prefix='../../../';
 const desktop=r.topicId==='bluebook'?`screenshots/bluebook-desktop.png`:`${prefix}${dir}/evidence/desktop.png`;
 const mobile=r.topicId==='bluebook'?`screenshots/bluebook-mobile.png`:`${prefix}${dir}/evidence/mobile.png`;
 rows.push(`| [${loadCatalog().topics.find(t=>t.id===r.topicId).title}](${prefix}${dir}/Readme.md) | ${m.promptId} | ${m.preview.kind} / ${m.preview.network} | [打开](${prefix}${m.preview.kind==='build'?`previews/${r.topicId}/${r.runId}`:dir}/index.html) | [桌面](${desktop}) · [手机](${mobile}) |`);
}
fs.copyFileSync('.cache/model-test-20261023/bluebook-visible.png',reportDir+'/screenshots/bluebook-desktop.png');
fs.copyFileSync('.cache/model-test-20261023/bluebook-mobile.png',reportDir+'/screenshots/bluebook-mobile.png');
fs.writeFileSync(`${reportDir}/validation.md`,lines.join('\n')+'\n');
fs.writeFileSync(`${reportDir}/Readme.md`,`# GPT 6.1 Sol / xhigh 全案例实验\n\n2026-10-23，按用户指定模型名称 \`gpt-6-1-sol\`、档位 \`xhigh\`，在当前 Codex 会话逐一实现 ${runs.length} 个参与主题；没有委派子代理。\`stock-watching\` 已归档，按 \`npm run topics:active\` 的结果跳过。小蓝书选用最大版本 v2，其余为 v1。\n\n工作在 \`experiment/gpt-6-1-sol-xhigh-20261023\` 分支完成；未获取历史实验实现，未修改发布源、域名、CNB 同步或外部部署设置。用户覆盖了新会话要求；本轮共享会话上下文，不能宣称隔离公平评测。\n\n| 主题 | 提示词 | 预览 / 网络 | 入口 | 截图 |\n|---|---|---|---|---|\n${rows.join('\n')}\n\n## 验证\n\n- ${checks.length}/${checks.length} 组 demo 检查通过，覆盖 HTTP、静态单文件 file://、390px、核心数值和交互、WebGL 不支持提示。\n- 摄像头专项通过：真实模型加载、模拟视频设备、权限拒绝及轨道释放。真实人手识别仍需真人设备确认。\n- 触摸专项通过：寻路绘制、电路连线/拖动/删除、地图画笔、流体注入、粒子吸引。\n- 站点专项在根路径与 Pages 子路径通过：筛选、排序、加载更多、有效链接、比较关系、无预览、单侧卸载、分享恢复与手机仅加载当前侧。不同输入与无预览使用内存 fixture，不伪造档案记录。\n- 仓库单元测试 11 项与浏览器回归 12 项通过。首页回归原先假设所有主题一屏展示，本轮按真实九项分页补充“加载更多”验收；未改变首页实现。\n- 数值、边界和首次快照指纹见 [验证明细](validation.md)。仓库维护命令日志见 [检查日志](checks.txt)。\n\n## 归档与复现\n\n每个 run 均保存 run.json、prompt.md、Readme.md、源码、首次产物 evidence/initial.zip、修复记录、验证记录和截图；构建型小蓝书另有独立 lockfile 与已生成 previews。首次快照在本轮浏览器验证前封存，含首次错误，后续修复没有覆盖快照。生成工具的原始脚本保存在 [generation-scripts.zip](generation-scripts.zip)，仅作证据，不应对定稿历史再次执行。\n\n先以端口 43903 运行静态服务：\n\n\`\`\`powershell\n$env:PORT='43903'\nnode scripts/serve.mjs --read-only\n\`\`\`\n\n另一终端执行 \`node tests/experiment-gpt-6-1-sol-20261023.mjs\`；其他专项用相应 experiment-*-20261023.mjs。浏览器依赖使用仓库 lockfile。\n\n## 边界\n\nThree.js r160 内嵌于 3D HTML 并保留 MIT 许可证。原型页使用 Tailwind 类与编译 CSS 兜底，仍按 CDN/外部图片登记为 required。YouTube 的 APP 需求根据主题补全，当前没有可用 Artifacts 插件；新哥特城市缺少测绘资料，交付原创米制比例设计。WebGL 自动化使用软件渲染，无法据此保证目标设备 60FPS 或所有机械姿态绝无几何相交。\n`);
console.log(`Finalized ${runs.length} runs; report: ${reportDir}/Readme.md`);
